"""Sanity checks on pipeline outputs. Run: python -m unittest discover tests -v"""
import os, json, unittest
import pandas as pd
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); D=os.path.join(ROOT,'data')
class T(unittest.TestCase):
    @classmethod
    def setUpClass(c):
        c.g=pd.read_csv(os.path.join(D,'station_season.csv.gz')); c.r=pd.read_csv(os.path.join(D,'district_risk.csv'))
        c.m=json.load(open(os.path.join(ROOT,'models','metrics.json')))
    def test_depth_range(self): self.assertTrue(self.g.depth.between(0,100).all())
    def test_years(self): self.assertTrue(self.g.year.between(2013,2019).all())
    def test_no_duplicate_station_season(self): self.assertFalse(self.g.duplicated(['station_id','year','season']).any())
    def test_seasons(self): self.assertEqual(set(self.g.season),{'Winter','Pre-monsoon','Monsoon','Post-monsoon'})
    def test_district_table(self):
        self.assertEqual(self.r.district_code.is_unique,True); self.assertGreater(len(self.r),500)
    def test_risk_probability(self):
        p=self.r.risk_prob.dropna(); self.assertTrue(p.between(0,1).all())
    def test_tiers(self): self.assertTrue(set(self.r.risk_tier)<={'Low','Medium','High','Insufficient data'})
    def test_critical_definition(self):
        c=self.r[self.r.priority=='Critical']; self.assertTrue((c.risk_tier=='High').all()); self.assertTrue((c.pre_depth>10).all())
    def test_forecast_beats_baseline(self):
        f=self.m['forecast']; self.assertLess(f['gradient_boosting']['MAE'],f['baseline_persistence']['MAE'])
    def test_classifier_beats_naive(self):
        k=self.m['risk']; self.assertGreater(k['cv_auc_random_forest'],k['cv_auc_naive_slope'])
    def test_site_pages(self):
        for p in ['index.html','dashboard.html','districts.html','trends.html','models.html','rainfall.html','findings.html']:
            f=os.path.join(ROOT,'docs',p); self.assertTrue(os.path.exists(f),p)
            self.assertNotIn('__DATA__',open(f,encoding='utf-8').read())
    def test_rainfall_panel(self):
        r=pd.read_csv(os.path.join(D,'rain_district_year.csv')); self.assertTrue(r.rain_monsoon.dropna().between(0,10000).all()); self.assertFalse(r.duplicated(['district_code','year']).any())
    def test_rainfall_join_coverage(self):
        r=pd.read_csv(os.path.join(D,'rain_district_year.csv')); self.assertGreater(self.r.district_code.isin(r.district_code).mean(),0.95)
    def test_rain_effect_positive(self):
        a=json.load(open(os.path.join(ROOT,'reports','rain_analysis.json'))); self.assertGreater(a['recovery_vs_monsoon_anomaly']['ci95'][0],0)
if __name__=='__main__': unittest.main()
