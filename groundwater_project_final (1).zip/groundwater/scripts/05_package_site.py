"""Copy the generated dashboard pages into docs/ so GitHub Pages (Deploy from branch -> /docs) can serve them."""
import os, shutil
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
src=os.path.join(ROOT,'dashboard'); dst=os.path.join(ROOT,'docs'); os.makedirs(dst,exist_ok=True)
for old in os.listdir(dst):
    if old.endswith('.html'): os.remove(os.path.join(dst,old))
pages=['dashboard.html','districts.html','trends.html','rainfall.html','models.html','findings.html']
for p in pages: shutil.copy(os.path.join(src,p),os.path.join(dst,p))
shutil.copy(os.path.join(src,'dashboard.html'),os.path.join(dst,'index.html'))   # landing page
open(os.path.join(dst,'.nojekyll'),'w').close()
print('docs/ ready:',sorted(os.listdir(dst)))
