import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
"""Model A: station-level next-year pre-monsoon depth forecast. Model B: district deterioration-risk classifier."""
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_curve, mean_absolute_error, mean_squared_error, r2_score, roc_auc_score
from sklearn.inspection import permutation_importance
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from scipy import stats
D=ROOT+'data/'; M={}
g=pd.read_csv(D+'station_season.csv.gz'); ds=pd.read_csv(D+'district_stats.csv'); rain=pd.read_csv(D+'rain_district_year.csv')
_b=rain[rain.year.between(2009,2019)].groupby('district_code').rain_monsoon.mean().rename('rain_mean'); rain=rain.merge(_b,on='district_code'); rain['rain_anom']=(rain.rain_monsoon/rain.rain_mean-1)*100
# ---------- Model A ----------
W=g.pivot_table(index=['station_id','year'],columns='season',values='depth').reset_index()
W.columns=['station_id','year','mon','post','pre','win']
info=g.groupby('station_id').agg(lat=('lat','first'),lon=('lon','first'),state_code=('state_code','first'),district_code=('district_code','first')).reset_index()
rows=[]
for y in range(2015,2020):
    prev=W[W.year==y-1].set_index('station_id'); prev2=W[W.year==y-2].set_index('station_id')[['pre']].rename(columns={'pre':'pre_l2'})
    tgt=W[(W.year==y)&W.pre.notna()].set_index('station_id')[['pre']].rename(columns={'pre':'target'})
    hist=W[W.year<y].groupby('station_id').pre.agg(pre_mean='mean',pre_n='count')
    x=tgt.join(prev.rename(columns={'pre':'pre_l1','mon':'mon_l1','post':'post_l1','win':'win_l1'}).drop(columns='year'),how='inner').join(prev2).join(hist)
    x['year']=y; rows.append(x.reset_index())
P=pd.concat(rows).merge(info,on='station_id'); P=P[P.pre_l1.notna()]
P['rec_l1']=P.pre_l1-P.post_l1; P['swing_l1']=P.pre_l1-P.mon_l1; P['trend_l2']=P.pre_l1-P.pre_l2
dmed=P.groupby(['district_code','year']).pre_l1.transform('median'); P['dist_pre_l1']=dmed
_r=rain[['district_code','year','rain_monsoon','rain_anom']].copy(); _r['year']+=1; _r.columns=['district_code','year','rain_mon_l1','rain_anom_l1']
P=P.merge(_r,on=['district_code','year'],how='left')
F=['pre_l1','mon_l1','post_l1','win_l1','pre_l2','pre_mean','pre_n','rec_l1','swing_l1','trend_l2','dist_pre_l1','lat','lon','state_code']
FR=F+['rain_mon_l1','rain_anom_l1']
tr=P[P.year<=2017]; te=P[P.year>=2018].copy()
mdl=HistGradientBoostingRegressor(max_iter=300,learning_rate=0.05,max_leaf_nodes=31,min_samples_leaf=40,l2_regularization=1.0,random_state=7)
mdl.fit(tr[F],tr.target-tr.pre_l1); te['pred']=te.pre_l1+mdl.predict(te[F])
def ev(p): return dict(MAE=round(mean_absolute_error(te.target,p),3),RMSE=round(float(np.sqrt(mean_squared_error(te.target,p))),3),R2=round(r2_score(te.target,p),4),within_1m=round(float((abs(te.target-p)<=1).mean()*100),1))
M['forecast']=dict(train_rows=len(tr),test_rows=len(te),train_years='target 2015-2017',test_years='target 2018-2019',
  baseline_persistence=ev(te.pre_l1),baseline_station_mean=ev(te.pre_mean.fillna(te.pre_l1)),gradient_boosting=ev(te.pred))
mdl2=HistGradientBoostingRegressor(max_iter=300,learning_rate=0.05,max_leaf_nodes=31,min_samples_leaf=40,l2_regularization=1.0,random_state=7)
mdl2.fit(tr[FR],tr.target-tr.pre_l1); te['pred_rain']=te.pre_l1+mdl2.predict(te[FR])
M['forecast']['gradient_boosting_with_rain']=ev(te.pred_rain)
te['err']=te.target-te.pred
ye=te.groupby('year').agg(actual=('target','median'),pred=('pred','median'),persist=('pre_l1','median'),n=('target','size')).round(2).reset_index(); ye.to_csv(D+'forecast_eval.csv',index=False)
# ---------- Model B ----------
pre=g[g.season=='Pre-monsoon']
def feats(y0,y1):
    w=g[g.year.between(y0,y1)]; p=w[w.season=='Pre-monsoon']; q=w[w.season=='Post-monsoon']; m=w[w.season=='Monsoon']
    f=pd.DataFrame({'pre_depth':p.groupby('district_code').depth.median(),'post_depth':q.groupby('district_code').depth.median(),'mon_depth':m.groupby('district_code').depth.median(),
      'pct_gt10':p.groupby('district_code').depth.apply(lambda x:(x>10).mean()*100),'depth_spread':p.groupby('district_code').depth.std(),
      'stations':w.groupby('district_code').station_id.nunique()})
    f['recovery']=f.pre_depth-f.post_depth; f['monsoon_rise']=f.pre_depth-f.mon_depth
    ann=p.groupby(['district_code','year']).depth.median().unstack()
    f['slope_in_window']=ann.apply(lambda r:stats.theilslopes(r.dropna().values,r.dropna().index.values)[0] if r.notna().sum()>=3 else np.nan,axis=1)
    rw=rain[rain.year.between(y0,y1)].groupby('district_code').rain_monsoon
    f['rain_mean']=rw.mean(); f['rain_cv']=rw.std()/rw.mean(); f['rain_anom_mean']=rain[rain.year.between(y0,y1)].groupby('district_code').rain_anom.mean()
    c=ds.set_index('district_code')[['lat','lon']]; return f.join(c)
A=feats(2013,2016)
# target: station-paired change in pre-monsoon depth, 2017-19 vs 2013-16
e=pre[pre.year<=2016].groupby('station_id').depth.median(); l=pre[pre.year>=2017].groupby('station_id').depth.median()
dd=pd.concat([e,l],axis=1,keys=['e','l']).dropna(); dd['d']=dd.l-dd.e; dd=dd.join(info.set_index('station_id').district_code)
chg=dd.groupby('district_code').agg(delta=('d','median'),n=('d','size'))
T=A.join(chg,how='inner'); T=T[(T.n>=3)&(T.stations>=3)].dropna(subset=['pre_depth','post_depth','mon_depth']); T['y']=(T.delta>0.5).astype(int)
FB=['pre_depth','post_depth','mon_depth','pct_gt10','depth_spread','stations','recovery','monsoon_rise','slope_in_window','lat','lon']
FB0=list(FB); FBR=FB0+['rain_mean','rain_cv','rain_anom_mean']
T=T.dropna(subset=['rain_mean']); y=T.y
cv=StratifiedKFold(5,shuffle=True,random_state=7)
rf=RandomForestClassifier(400,min_samples_leaf=3,class_weight='balanced',random_state=7,n_jobs=1)
lr=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000,class_weight='balanced'))
X0=T[FB0].fillna(T[FB0].median()); XR=T[FBR].fillna(T[FBR].median())
oof0=cross_val_predict(rf,X0,y,cv=cv,method='predict_proba')[:,1]; oofR=cross_val_predict(rf,XR,y,cv=cv,method='predict_proba')[:,1]
A0,AR=[],[]
for sd in (11,22,33,44,55):   # repeated CV with different splits to check the rainfall gain is not split luck
    c2=StratifiedKFold(5,shuffle=True,random_state=sd)
    A0.append(roc_auc_score(y,cross_val_predict(rf,X0,y,cv=c2,method='predict_proba')[:,1])); AR.append(roc_auc_score(y,cross_val_predict(rf,XR,y,cv=c2,method='predict_proba')[:,1]))
auc0,aucR=float(np.mean(A0)),float(np.mean(AR)); sd0,sdR=float(np.std(A0)),float(np.std(AR)); useR=aucR>auc0+0.005
FB=FBR if useR else FB0; X=XR if useR else X0; oof_rf=oofR if useR else oof0
oof_lr=cross_val_predict(lr,X,y,cv=cv,method='predict_proba')[:,1]
naive=-T.slope_in_window.fillna(0)*0+T.slope_in_window.fillna(0)
M['risk']=dict(districts=len(T),positive_rate=round(float(y.mean()),3),target='district median pre-monsoon depth deepened >0.5 m in 2017-19 vs 2013-16',
  cv_auc_random_forest=round(roc_auc_score(y,oof_rf),3),cv_auc_rf_without_rain=round(auc0,3),cv_auc_rf_with_rain=round(aucR,3),repeat_cv_sd_without_rain=round(sd0,3),repeat_cv_sd_with_rain=round(sdR,3),rainfall_features_used=bool(useR),cv_auc_logistic=round(roc_auc_score(y,oof_lr),3),cv_auc_naive_slope=round(roc_auc_score(y,naive),3))
rf.fit(X,y); pi=permutation_importance(rf,X,y,n_repeats=15,random_state=7,scoring='roc_auc')
imp=pd.Series(pi.importances_mean,index=FB).sort_values(ascending=False); M['risk']['importance']=imp.round(4).to_dict()
# score districts on the latest comparable window (2016-2019)
S=feats(2016,2019); S=S[S.stations>=3].dropna(subset=['pre_depth','post_depth','mon_depth']); S['risk_prob']=rf.predict_proba(S[FB].fillna(T[FB].median()))[:,1]
out=ds.merge(S[['risk_prob']].reset_index(),on='district_code',how='left')
out['risk_tier']=pd.cut(out.risk_prob,[-1,0.4,0.6,2],labels=['Low','Medium','High']).astype(object).fillna('Insufficient data')
out['priority']=np.where((out.risk_tier=='High')&(out.pre_depth>10),'Critical',out.risk_tier)
out.round(3).to_csv(D+'district_risk.csv',index=False)
M['risk']['tiers']=out.risk_tier.value_counts().to_dict(); M['risk']['critical_districts']=int((out.priority=='Critical').sum())
# ---- extra artefacts for the dashboard: ROC curves and per-state forecast error
def _roc(s):
    f,tp,_=roc_curve(y,s); i=np.linspace(0,len(f)-1,min(45,len(f))).astype(int); return [[round(float(f[j]),3),round(float(tp[j]),3)] for j in i]
M['roc']={'Trend-only rule':_roc(naive),'Logistic regression':_roc(oof_lr),'Random forest':_roc(oof_rf)}
sn=g.groupby('state_code').state.first(); te['state']=te.state_code.map(sn); te['ae_m']=(te.target-te.pred).abs(); te['ae_b']=(te.target-te.pre_l1).abs()
bs=te.groupby('state').agg(n=('target','size'),model=('ae_m','mean'),baseline=('ae_b','mean')).query('n>=400').sort_values('n',ascending=False).head(8).round(2)
M['forecast_by_state']=[[s,float(r.baseline),float(r.model),int(r.n)] for s,r in bs.iterrows()]
json.dump(M,open(ROOT+'models/metrics.json','w'),indent=2); print(json.dumps(M,indent=2))
print(out[out.priority=='Critical'].sort_values('risk_prob',ascending=False)[['district','state','pre_depth','sen_slope','risk_prob']].head(12).to_string())
