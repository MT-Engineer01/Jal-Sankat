"""How much of groundwater recovery and deepening is explained by monsoon rainfall? (district fixed effects, cluster-robust SE)"""
import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
import pandas as pd, numpy as np, json
from scipy import stats
D=ROOT+'data/'; g=pd.read_csv(D+'station_season.csv.gz'); rain=pd.read_csv(D+'rain_district_year.csv'); ds=pd.read_csv(D+'district_stats.csv')
base=rain[rain.year.between(2009,2019)].groupby('district_code').rain_monsoon.agg(rain_mean='mean',rain_sd='std')
rain=rain.merge(base,on='district_code'); rain['rain_anom']=(rain.rain_monsoon/rain.rain_mean-1)*100
pre=g[g.season=='Pre-monsoon']; post=g[g.season=='Post-monsoon']
r=pre[['station_id','year','depth','district_code']].merge(post[['station_id','year','depth']],on=['station_id','year'],suffixes=('_pre','_post'))
r['recovery']=r.depth_pre-r.depth_post   # positive = water table rose over the monsoon
rec=r.groupby(['district_code','year']).recovery.median().reset_index()
pd_=pre.groupby(['district_code','year']).depth.median().reset_index().rename(columns={'depth':'pre'})
nxt=pd_.copy(); nxt['year']-=1; chg=pd_.merge(nxt,on=['district_code','year'],suffixes=('','_next')); chg['next_change']=chg.pre_next-chg.pre   # positive = deeper next year
P=rec.merge(chg[['district_code','year','next_change']],on=['district_code','year'],how='outer').merge(rain[['district_code','year','rain_monsoon','rain_anom']],on=['district_code','year'])
P=P[P.year.between(2013,2019)]
def fe(df,y,x='rain_anom'):
    d=df.dropna(subset=[y,x]).copy(); d=d[d.groupby('district_code')[y].transform('size')>=3]
    for c in (y,x): d[c+'_d']=d[c]-d.groupby('district_code')[c].transform('mean')
    sxx=(d[x+'_d']**2).sum(); b=(d[x+'_d']*d[y+'_d']).sum()/sxx; e=d[y+'_d']-b*d[x+'_d']
    G=d.district_code.nunique(); se=np.sqrt(((d.assign(s=d[x+'_d']*e).groupby('district_code').s.sum()**2).sum())*G/(G-1)/sxx**2)
    return dict(n=len(d),districts=G,beta_per_10pct=round(b*10,3),ci95=[round((b-1.96*se)*10,3),round((b+1.96*se)*10,3)])
R={'recovery_vs_monsoon_anomaly':fe(P,'recovery'),'next_year_depth_change_vs_monsoon_anomaly':fe(P,'next_change')}
R['robustness_recovery_excluding_monsoon_gt_5000mm']=fe(P[P.rain_monsoon<=5000],'recovery')   # a few very wet Meghalaya/Konkan district-years look implausibly high
pc=P.dropna(subset=['recovery','rain_anom']).groupby('district_code').apply(lambda x:x.recovery.corr(x.rain_anom) if len(x)>=5 else np.nan,include_groups=False).dropna()
R['district_corr_recovery_rain']=dict(n=len(pc),median=round(float(pc.median()),3),share_positive=round(float((pc>0).mean()*100),1))
q=P.dropna(subset=['recovery','rain_anom']); q=q[q.groupby('district_code').recovery.transform('size')>=3].copy(); q['rec_dm']=q.recovery-q.groupby('district_code').recovery.transform('mean')
q['bin']=pd.cut(q.rain_anom,[-101,-30,-15,0,15,30,1000],labels=['below -30%','-30 to -15%','-15 to 0%','0 to +15%','+15 to +30%','above +30%'])
R['bins']=[[str(k),round(float(v.rec_dm.mean()),2),int(len(v))] for k,v in q.groupby('bin',observed=True)]
# rainfall trend 2013-2019 per district and link to water-table trend
def tr(x):
    x=x.dropna()
    if len(x)<5: return pd.Series({'rain_slope':np.nan,'rain_p':np.nan})
    return pd.Series({'rain_slope':stats.theilslopes(x.rain_monsoon.values,x.year.values)[0],'rain_p':stats.kendalltau(x.year,x.rain_monsoon)[1]})
rt=rain[rain.year.between(2013,2019)].groupby('district_code').apply(tr,include_groups=False).reset_index()
S=ds[['district_code','district','state','sen_slope','mk_p','significant_deepening']].merge(base.reset_index(),on='district_code',how='left').merge(rt,on='district_code',how='left').merge(pc.rename('corr_recovery_rain').reset_index(),on='district_code',how='left')
S['rain_cv']=S.rain_sd/S.rain_mean
dec=S.significant_deepening==1; falling=(S.rain_slope<0)&(S.rain_p<0.1)
S['depletion_driver']=np.select([dec&falling,dec&~falling&S.rain_slope.notna()],['Rain-linked','Extraction-suspect'],'Not deepening')
S.round(3).to_csv(D+'rain_district_stats.csv',index=False)
R['deepening_districts']=int(dec.sum()); R['drivers']=S.depletion_driver.value_counts().to_dict()
sp=S[S.depletion_driver=='Extraction-suspect']; R['extraction_suspect_top_states']=sp.state.value_counts().head(5).to_dict()
R['rain_median_monsoon_mm_by_driver']=S.groupby('depletion_driver').rain_mean.median().round(0).to_dict()
R['top_extraction_suspect']=[[x.district,x.state,round(x.sen_slope,2),int(x.rain_mean)] for x in sp.sort_values('sen_slope',ascending=False).head(8).itertuples()]
json.dump(R,open(ROOT+'reports/rain_analysis.json','w'),indent=2); print(json.dumps(R,indent=2))
