import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
"""Clean CGWB depth-to-water-level data and aggregate to station x year x season."""
import pandas as pd, numpy as np
RAW=ROOT+'data/raw/cgwb-changes-in-depth-to-water-level.csv'
OUT=ROOT+'data/'
log=[]
d=pd.read_csv(RAW,parse_dates=['date']); log.append(f'raw rows={len(d):,}, stations(name+coords)={d.groupby(["station_name","latitude","longitude"]).ngroups:,}')
d=d.drop(columns=['id','source'])
n=len(d); d=d[(d.currentlevel>=0)&(d.currentlevel<=100)]
log.append(f'dropped {n-len(d):,} rows with depth <0 or >100 m (sensor/typo outliers)')
d['station_id']=d.latitude.round(5).astype(str)+'_'+d.longitude.round(5).astype(str)+'_'+d.station_name.str.strip().str.lower()
m=d.date.dt.month
d['season']=np.select([m.isin([12,1,2,3]),m.isin([4,5,6]),m.isin([7,8,9])],['Winter','Pre-monsoon','Monsoon'],'Post-monsoon')
d['year']=d.date.dt.year
g=d.groupby(['station_id','year','season'],as_index=False).agg(depth=('currentlevel','median'),n_obs=('currentlevel','size'),
    state=('state_name','first'),state_code=('state_code','first'),district=('district_name','first'),district_code=('district_code','first'),
    lat=('latitude','first'),lon=('longitude','first'),basin=('basin','first'))
log.append(f'after collapsing duplicates/daily readings to station-year-season: {len(g):,} rows, {g.station_id.nunique():,} stations')
n=len(g); g=g[g.year.between(2013,2019)]
log.append(f'kept 2013-2019 only (2020 has just 12 pre-monsoon stations, 2021+ also sparse: {n-len(g):,} rows dropped) -> {len(g):,} rows')
g['depth']=g.depth.round(2)
g.to_csv(OUT+'station_season.csv.gz',index=False)
log.append('states=%d districts=%d'%(g.state.nunique(),g.district_code.nunique()))
log.append('rows by season: '+str(g.season.value_counts().to_dict()))
open(OUT+'cleaning_log.txt','w').write('\n'.join(log)); print('\n'.join(log))
print(g.groupby('year').station_id.nunique().to_dict())
