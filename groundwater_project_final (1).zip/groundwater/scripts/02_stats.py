import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
"""District trend statistics: Sen's slope + Kendall tau (Mann-Kendall), recovery, hypothesis tests."""
import pandas as pd, numpy as np, json
from scipy import stats
D=ROOT+'data/'
g=pd.read_csv(D+'station_season.csv.gz')
meta=g.groupby('district_code').agg(district=('district','first'),state=('state','first'),lat=('lat','median'),lon=('lon','median'),stations=('station_id','nunique')).reset_index()
pre=g[g.season=='Pre-monsoon']; post=g[g.season=='Post-monsoon']
# annual pre-monsoon district depth = median of station medians
ann=pre.groupby(['district_code','year']).depth.median().unstack()
def mk(row):
    y=row.dropna()
    if len(y)<5: return pd.Series({'sen_slope':np.nan,'mk_p':np.nan,'n_years':len(y)})
    tau,p=stats.kendalltau(y.index,y.values); s=stats.theilslopes(y.values,y.index.values)[0]
    return pd.Series({'sen_slope':s,'mk_p':p,'n_years':len(y)})
tr=ann.apply(mk,axis=1).reset_index()
# recovery = pre-monsoon depth - post-monsoon depth, same station & year (positive = water table rose)
r=pre[['station_id','year','depth','district_code']].merge(post[['station_id','year','depth']],on=['station_id','year'],suffixes=('_pre','_post'))
r['recovery']=r.depth_pre-r.depth_post
rec=r.groupby(['district_code','year']).recovery.median().unstack()
rec_mean=r.groupby('district_code').recovery.median().rename('recovery_m')
rec_tr=rec.apply(lambda row: stats.theilslopes(row.dropna().values,row.dropna().index.values)[0] if row.notna().sum()>=4 else np.nan,axis=1).rename('recovery_trend')
last=g[g.year.between(2017,2019)]
lp=last[last.season=='Pre-monsoon'].groupby('district_code').depth.agg(pre_depth='median',pct_gt10=lambda x:(x>10).mean()*100,pct_gt20=lambda x:(x>20).mean()*100)
vol=g.groupby(['district_code','station_id']).depth.std().groupby('district_code').median().rename('volatility')
ds=meta.merge(tr,on='district_code',how='left').merge(rec_mean,on='district_code',how='left').merge(rec_tr,on='district_code',how='left').merge(lp,on='district_code',how='left').merge(vol,on='district_code',how='left')
ds['significant_deepening']=((ds.sen_slope>0)&(ds.mk_p<0.1)).astype(int)
ds['significant_recovery_gain']=((ds.sen_slope<0)&(ds.mk_p<0.1)).astype(int)
ds.round(3).to_csv(D+'district_stats.csv',index=False)
out=['districts: %d with trend (>=5 yrs): %d'%(len(ds),ds.sen_slope.notna().sum()),
 'significant deepening (p<0.1): %d | significant improvement: %d'%(ds.significant_deepening.sum(),ds.significant_recovery_gain.sum()),
 'median Sen slope m/yr: %.3f'%ds.sen_slope.median(), 'districts with pre-monsoon depth >10 m (2017-19): %d'%(ds.pre_depth>10).sum()]
# national tests
nat=ann.median().dropna(); tau,p=stats.kendalltau(nat.index,nat.values); out.append('national pre-monsoon median depth by year: %s ; tau=%.2f p=%.3f'%(nat.round(2).to_dict(),tau,p))
natrec=rec.median().dropna(); tau2,p2=stats.kendalltau(natrec.index,natrec.values); out.append('national recovery by year: %s ; tau=%.2f p=%.3f'%(natrec.round(2).to_dict(),tau2,p2))
a=r[r.year.between(2013,2016)].groupby('station_id').recovery.median(); b=r[r.year.between(2017,2019)].groupby('station_id').recovery.median()
j=pd.concat([a,b],axis=1,keys=['early','late']).dropna(); w=stats.wilcoxon(j.early,j.late)
out.append('Wilcoxon paired recovery 2013-16 vs 2017-19 on %d stations: median early=%.2f late=%.2f p=%.2e'%(len(j),j.early.median(),j.late.median(),w.pvalue))
st=ds.groupby('state').agg(districts=('district_code','count'),slope=('sen_slope','median'),pre_depth=('pre_depth','median')).round(3).sort_values('slope',ascending=False)
out.append('state median Sen slope (top deepening):\n'+st.head(8).to_string())
open(ROOT+'reports/stats_summary.txt','w').write('\n'.join(out)); print('\n'.join(out))
nat_df=pd.DataFrame({'year':nat.index,'pre_depth':nat.values}).merge(pd.DataFrame({'year':natrec.index,'recovery':natrec.values}),on='year'); nat_df.round(3).to_csv(D+'national_trend.csv',index=False)
