"""Build the 6-page static dashboard (dashboard/*.html) from the pipeline outputs."""
import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
import pandas as pd, numpy as np, json
B=ROOT; D=B+'data/'
g=pd.read_csv(D+'station_season.csv.gz'); r=pd.read_csv(D+'district_risk.csv'); rs=pd.read_csv(D+'rain_district_stats.csv'); nat=pd.read_csv(D+'national_trend.csv')
M=json.load(open(B+'models/metrics.json')); RA=json.load(open(B+'reports/rain_analysis.json')); f=M['forecast']; k=M['risk']
tier={'Low':0,'Medium':1,'High':2,'Critical':3,'Insufficient data':4}; drv={'Not deepening':0,'Extraction-suspect':1,'Rain-linked':2}
r=r.merge(rs[['district_code','rain_mean','rain_slope','depletion_driver']],on='district_code',how='left')
nz=lambda v,d: None if pd.isna(v) else round(float(v),d)
dist=[[x.district,x.state,round(x.lat,2),round(x.lon,2),nz(x.pre_depth,1),nz(x.sen_slope,2),nz(x.risk_prob,2),tier[x.priority],int(x.stations),None if pd.isna(x.rain_mean) else int(x.rain_mean),drv.get(x.depletion_driver,0),int(x.significant_deepening)] for x in r.itertuples()]
pr=r.set_index('district_code').priority.map(tier)
s=g.groupby('station_id').agg(lat=('lat','first'),lon=('lon','first'),dc=('district_code','first'),st=('state','first')).reset_index(); sts=sorted(s.st.unique()); si={x:i for i,x in enumerate(sts)}; s['t']=s.dc.map(pr).fillna(4).astype(int)
stn=[[int(round(a*100)),int(round(b*100)),int(t),si[z]] for a,b,t,z in zip(s.lon,s.lat,s.t,s.st)]
m=g.groupby(['year','season']).depth.median().unstack().round(2); yrs=m.index.tolist()
seas=dict(years=yrs,pre=m['Pre-monsoon'].tolist(),mon=m['Monsoon'].tolist(),post=m['Post-monsoon'].tolist())
rec=[[str(int(a)),round(float(b),2)] for a,b in zip(nat.year,nat.recovery)]
p=g[g.season=='Pre-monsoon']; keep=p.groupby('station_id').year.nunique(); p=p[p.station_id.isin(keep[keep>=5].index)]
h=p.groupby(['state','year']).depth.median().unstack().reindex(columns=yrs); cnt=p.groupby('state').station_id.nunique()
h=h.dropna(); h=h.loc[[x for x in cnt.loc[h.index].sort_values(ascending=False).head(12).index]]; h=h.loc[h.mean(axis=1).sort_values(ascending=False).index]
heat=[[st,[round(float(v),1) for v in row]] for st,row in h.iterrows()]
q=rs.dropna(subset=['sen_slope','rain_slope']); sc=[[round(float(a),1),round(float(b),2),drv[c],n,st] for a,b,c,n,st in zip(q.rain_slope,q.sen_slope,q.depletion_driver,q.district,q.state)]
cr=r[r.priority=='Critical']; rf=RA['recovery_vs_monsoon_anomaly']
find=[f"{int((r.pre_depth.round(1)>10).sum())} of {len(r)} districts have a pre-monsoon water table deeper than 10 m (2017–19 median).",
 f"{int(r.significant_deepening.sum())} districts show a statistically significant deepening trend (Mann-Kendall p < 0.1) against {int(r.significant_recovery_gain.sum())} that are improving.",
 f"{len(cr)} districts are flagged Critical; {int((cr.state=='Punjab').sum())} are in Punjab and {int((cr.state=='Haryana').sum())} in Haryana.",
 f"A monsoon 10% above normal adds {rf['beta_per_10pct']} m of recovery in the same year (95% CI {rf['ci95'][0]} to {rf['ci95'][1]}; district fixed effects).",
 f"{RA['drivers'].get('Extraction-suspect',0)} of {RA['deepening_districts']} deepening districts show no significant fall in monsoon rainfall, which points towards pumping (a hypothesis, not proven here).",
 f"The risk classifier reaches a cross-validated AUC of {k['cv_auc_random_forest']} against {k['cv_auc_naive_slope']} for a trend-only rule.",
 f"The depth forecast cuts MAE from {f['baseline_persistence']['MAE']} m to {f['gradient_boosting']['MAE']} m on unseen 2018–19 data, but is worse than the baseline in some states such as Gujarat.",
 f"Adding rainfall barely improves prediction (AUC {k['cv_auc_rf_without_rain']} to {k['cv_auc_rf_with_rain']}, within noise): rainfall explains why levels move better than it predicts them."]
hd=dict(trend=f"Across wells, the pre-monsoon water table sits around {np.median(seas['pre']):.1f} m and has not moved much nationally. The monsoon lifts it by about {np.mean([x[1] for x in rec]):.1f} m a year, but the size of that rebound swings with rainfall.",
 rain=f"A monsoon 10% above normal lifts the water table by an extra {rf['beta_per_10pct']} m that year, and {RA['drivers'].get('Extraction-suspect',0)} of {RA['deepening_districts']} deepening districts show no matching rainfall decline.")
rain=dict(bins=RA['bins'],drv=RA['drivers'],dep=RA['deepening_districts'],top=RA['top_extraction_suspect'])
data=dict(sts=sts,stn=stn,dist=dist,seas=seas,rec=rec,heat=heat,sc=sc,rain=rain,fc=f,fst=M['forecast_by_state'],roc=M['roc'],auc=[k['cv_auc_naive_slope'],k['cv_auc_logistic'],k['cv_auc_random_forest']],imp=k['importance'],find=find,hd=hd)
tpl=open(B+'dashboard/template.html',encoding='utf-8').read(); js=json.dumps(data,separators=(',',':'))
for fn,pg in [('dashboard','overview'),('districts','districts'),('trends','trends'),('rainfall','rainfall'),('models','models'),('findings','findings')]:
    open(B+f'dashboard/{fn}.html','w',encoding='utf-8').write(tpl.replace('__PAGE__',pg).replace('__DATA__',js))
print('built 6 pages,',len(js)//1024,'KB data each')
