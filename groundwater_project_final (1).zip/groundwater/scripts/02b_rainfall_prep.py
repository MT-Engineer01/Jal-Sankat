"""Aggregate daily district rainfall (India-WRIS via India Data Portal) to district x year totals.
Uses only the 'actual' column (mm/day). The 'rfs' and 'deviation' columns are not used: 'rfs' is not rainfall
and 'deviation' contains extreme values when the normal is near zero."""
import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
import pandas as pd, numpy as np
RAW=ROOT+'data/raw/daily-rainfall-data-district-level.csv'; OUT=ROOT+'data/rain_district_year.csv'
if not os.path.exists(RAW):
    print('rainfall raw file not found; using existing',OUT); raise SystemExit(0)
P={'monsoon':[6,7,8,9],'pre':[3,4,5],'post':[10,11,12]}; need={'monsoon':122,'pre':92,'post':92,'annual':365}
acc=[]
for c in pd.read_csv(RAW,usecols=['date','district_code','actual'],chunksize=500000,dtype={'district_code':str}):
    d=pd.to_datetime(c.date); c['year']=d.dt.year; c['m']=d.dt.month; c=c[c.year<=2023]
    for k,ms in list(P.items())+[('annual',list(range(1,13)))]:
        s=c[c.m.isin(ms)].groupby(['district_code','year']).actual.agg(['sum','count']).reset_index(); s['p']=k; acc.append(s)
a=pd.concat(acc).groupby(['district_code','year','p'],as_index=False).sum()
a['ok']=a['count']>=a.p.map(need)*0.8; a.loc[~a.ok,'sum']=np.nan
w=a.pivot(index=['district_code','year'],columns='p',values='sum').add_prefix('rain_').reset_index()
w['district_code']=w.district_code.astype(int); w.round(1).to_csv(OUT,index=False)
print('district-years:',len(w),'| districts:',w.district_code.nunique(),'| years',w.year.min(),'-',w.year.max())
print('monsoon missing %:',round(w.rain_monsoon.isna().mean()*100,1)); print(w.groupby('year').rain_monsoon.median().round(0).to_dict())
