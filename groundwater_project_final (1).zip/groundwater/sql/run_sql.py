import os; ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))+os.sep
import sqlite3, pandas as pd
D=ROOT; con=sqlite3.connect(D+'data/groundwater.db')
pd.read_csv(D+'data/station_season.csv.gz').to_sql('station_season',con,if_exists='replace',index=False)
pd.read_csv(D+'data/district_risk.csv').to_sql('district_risk',con,if_exists='replace',index=False)
out=[]
for i,q in enumerate([x for x in open(D+'sql/queries.sql').read().split(';') if 'SELECT' in x],1):
    out.append(f'--- Q{i}\n'+pd.read_sql(q,con).to_string(index=False)+'\n')
open(D+'reports/sql_results.txt','w').write('\n'.join(out)); print('\n'.join(out)); con.close()
