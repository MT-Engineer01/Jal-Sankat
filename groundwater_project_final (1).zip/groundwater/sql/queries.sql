-- Groundwater Stress Early-Warning | SQL (SQLite). Tables: station_season, district_risk
-- Q1 headline KPIs
SELECT (SELECT COUNT(DISTINCT station_id) FROM station_season) AS stations,
       (SELECT COUNT(*) FROM district_risk) AS districts,
       (SELECT COUNT(*) FROM district_risk WHERE pre_depth>10) AS districts_deeper_than_10m,
       (SELECT COUNT(*) FROM district_risk WHERE priority='Critical') AS critical_districts;
-- Q2 state ranking: deepening speed with window functions
WITH s AS (SELECT state, COUNT(*) AS districts, ROUND(AVG(sen_slope),3) AS avg_slope_m_per_yr, ROUND(AVG(pre_depth),1) AS avg_pre_depth,
           SUM(priority='Critical') AS critical FROM district_risk WHERE sen_slope IS NOT NULL GROUP BY state HAVING districts>=5)
SELECT state, districts, avg_slope_m_per_yr, avg_pre_depth, critical, RANK() OVER (ORDER BY avg_slope_m_per_yr DESC) AS deepening_rank FROM s ORDER BY deepening_rank LIMIT 10;
-- Q3 seasonal depth profile (median proxy via AVG) by year
SELECT year, ROUND(AVG(CASE WHEN season='Pre-monsoon' THEN depth END),2) AS pre, ROUND(AVG(CASE WHEN season='Monsoon' THEN depth END),2) AS monsoon,
       ROUND(AVG(CASE WHEN season='Post-monsoon' THEN depth END),2) AS post FROM station_season GROUP BY year ORDER BY year;
-- Q4 year-over-year change in pre-monsoon average depth (LAG)
WITH y AS (SELECT year, AVG(depth) AS d FROM station_season WHERE season='Pre-monsoon' GROUP BY year)
SELECT year, ROUND(d,2) AS avg_depth, ROUND(d-LAG(d) OVER (ORDER BY year),2) AS yoy_change FROM y ORDER BY year;
-- Q5 hotspot concentration: share of deep (>20 m) pre-monsoon readings by state
WITH x AS (SELECT state, SUM(depth>20) AS deep, COUNT(*) AS n FROM station_season WHERE season='Pre-monsoon' AND year>=2017 GROUP BY state)
SELECT state, deep, ROUND(100.0*deep/n,1) AS pct_deep, ROUND(100.0*SUM(deep) OVER (ORDER BY deep DESC)/SUM(deep) OVER (),1) AS cum_share_of_all_deep FROM x ORDER BY deep DESC LIMIT 8;
-- Q6 drill-down: top critical districts
SELECT district, state, pre_depth, sen_slope, ROUND(risk_prob,2) AS risk_prob, stations FROM district_risk WHERE priority='Critical' ORDER BY risk_prob DESC LIMIT 10;
